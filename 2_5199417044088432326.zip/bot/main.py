import html
import json
import logging
import os
import psycopg
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
import urllib.parse
from datetime import datetime, timedelta, timezone

import telebot
from telebot import types

# ================= НАСТРОЙКИ =================
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
if not BOT_TOKEN:
    raise SystemExit("Не задан TELEGRAM_BOT_TOKEN. Добавьте токен в переменные окружения.")
if not DATABASE_URL:
    raise SystemExit("Не задан DATABASE_URL. Проверьте строку подключения PostgreSQL.")

SUB_PRICE_STARS = 59
SUB_DAYS = 30
BOT_USERNAME = None
# =============================================

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")

# Временное состояние: кому сейчас пишет пользователь
# Оно очищается при перезапуске; сообщения и оплаты хранятся в PostgreSQL.
user_state = {}

# ================= БАЗА ДАННЫХ =================
def db_connect():
    return psycopg.connect(DATABASE_URL)


def init_db():
    try:
        with db_connect() as conn:
            conn.execute("SELECT 1 FROM telegram_bot_users LIMIT 0")
            conn.execute("SELECT 1 FROM telegram_bot_messages LIMIT 0")
            conn.execute("SELECT 1 FROM telegram_bot_payments LIMIT 0")
    except psycopg.Error as exc:
        raise RuntimeError(
            "Схема бота отсутствует в PostgreSQL. Запустите "
            "pnpm --filter @workspace/db run push. "
            f"Тип ошибки: {type(exc).__name__}"
        ) from None


def save_user(user: types.User):
    now = datetime.now(timezone.utc)
    full_name = f"{user.first_name or ''} {user.last_name or ''}".strip() or "Без имени"
    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO telegram_bot_users (user_id, username, full_name, created_at)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (user_id) DO UPDATE SET
                username = EXCLUDED.username,
                full_name = EXCLUDED.full_name
            """,
            (user.id, user.username, full_name, now),
        )


def user_exists(user_id: int) -> bool:
    with db_connect() as conn:
        row = conn.execute(
            "SELECT 1 FROM telegram_bot_users WHERE user_id = %s", (user_id,)
        ).fetchone()
    return row is not None


def get_sub_status(user_id: int):
    with db_connect() as conn:
        row = conn.execute(
            "SELECT sub_until FROM telegram_bot_users WHERE user_id = %s", (user_id,)
        ).fetchone()
    if not row or not row[0]:
        return False, None
    until_dt = row[0]
    if until_dt.tzinfo is None:
        until_dt = until_dt.replace(tzinfo=timezone.utc)
    else:
        until_dt = until_dt.astimezone(timezone.utc)
    if until_dt > datetime.now(timezone.utc):
        return True, until_dt
    return False, None


def activate_subscription(user_id: int, days: int, amount: int, charge_id: str) -> datetime:
    now = datetime.now(timezone.utc)
    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO telegram_bot_users (user_id, full_name, created_at)
            VALUES (%s, %s, %s)
            ON CONFLICT (user_id) DO NOTHING
            """,
            (user_id, "Без имени", now),
        )
        row = conn.execute(
            "SELECT sub_until FROM telegram_bot_users WHERE user_id = %s FOR UPDATE",
            (user_id,),
        ).fetchone()
        current_until = row[0] if row else None
        inserted = conn.execute(
            """
            INSERT INTO telegram_bot_payments (user_id, amount, charge_id, paid_at)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (charge_id) DO NOTHING
            RETURNING id
            """,
            (user_id, amount, charge_id, now),
        ).fetchone()
        if not inserted:
            if current_until is None:
                return now
            if current_until.tzinfo is None:
                return current_until.replace(tzinfo=timezone.utc)
            return current_until.astimezone(timezone.utc)

        if current_until is not None:
            if current_until.tzinfo is None:
                current_until = current_until.replace(tzinfo=timezone.utc)
            else:
                current_until = current_until.astimezone(timezone.utc)
        base_dt = current_until if current_until and current_until > now else now
        new_until = base_dt + timedelta(days=days)
        conn.execute(
            "UPDATE telegram_bot_users SET sub_until = %s WHERE user_id = %s",
            (new_until, user_id),
        )
    return new_until


def save_message_record(sender_id: int, receiver_id: int) -> int:
    with db_connect() as conn:
        row = conn.execute(
            """
            INSERT INTO telegram_bot_messages (sender_id, receiver_id)
            VALUES (%s, %s)
            RETURNING id
            """,
            (sender_id, receiver_id),
        ).fetchone()
    return row[0]


def get_message_sender(msg_db_id: int):
    with db_connect() as conn:
        row = conn.execute(
            "SELECT sender_id, receiver_id FROM telegram_bot_messages WHERE id = %s",
            (msg_db_id,),
        ).fetchone()
    return row


# ================= КЛАВИАТУРЫ И МЕНЮ =================
def main_menu_kb(user_id: int, is_active: bool) -> types.InlineKeyboardMarkup:
    link = f"https://t.me/{BOT_USERNAME}?start={user_id}"
    share_text = urllib.parse.quote("💌 Напиши мне анонимное сообщение!")
    share_url = f"https://t.me/share/url?url={urllib.parse.quote(link)}&text={share_text}"

    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(types.InlineKeyboardButton("📢 Поделиться ссылкой в канал / чат", url=share_url))
    if is_active:
        kb.add(types.InlineKeyboardButton(f"🔄 Продлить подписку (+{SUB_DAYS} дн. / {SUB_PRICE_STARS} ★)", callback_data="buy_info"))
    else:
        kb.add(types.InlineKeyboardButton(f"👁 Видеть отправителей — {SUB_PRICE_STARS} ★", callback_data="buy_info"))
    kb.add(types.InlineKeyboardButton("👤 Статус подписки", callback_data="profile"))
    return kb


def send_main_menu(chat_id: int, user_id: int):
    active, until_dt = get_sub_status(user_id)
    link = f"https://t.me/{BOT_USERNAME}?start={user_id}"

    if active:
        sub_line = f"⭐️ <b>Подписка активна</b> до {until_dt.strftime('%d.%m.%Y %H:%M')} UTC\n<i>Вы видите отправителей всех новых сообщений.</i>"
    else:
        sub_line = (
            f"🔒 <b>Режим:</b> стандартный (отправители скрыты).\n"
            f"Подключите подписку за <b>{SUB_PRICE_STARS} ★</b>, чтобы видеть имена новых отправителей."
        )

    text = (
        "👋 <b>Анонимные сообщения для вашего канала</b>\n\n"
        "Разместите эту ссылку в описании канала или в посте:\n"
        f"<code>{link}</code>\n\n"
        f"{sub_line}"
    )
    bot.send_message(chat_id, text, reply_markup=main_menu_kb(user_id, active), disable_web_page_preview=True)


def format_sender_block(sender: types.User) -> str:
    safe_name = html.escape(f"{sender.first_name or ''} {sender.last_name or ''}".strip() or "Без имени")
    username_str = f"@{html.escape(sender.username)}" if sender.username else "не указан"
    return (
        "\n\n━━━━━━━━━━━━━━━\n"
        "👁 <b>Отправитель (по подписке):</b>\n"
        f"👤 <a href='tg://user?id={sender.id}'>{safe_name}</a>\n"
        f"🔗 Юзернейм: {username_str}"
    )


# ================= КОМАНДЫ =================
@bot.message_handler(commands=["start"])
def cmd_start(message: types.Message):
    save_user(message.from_user)
    parts = message.text.split(maxsplit=1)

    # Переход по чужой ссылке: /start 123456789
    if len(parts) > 1 and parts[1].isdigit():
        target_id = int(parts[1])
        if not user_exists(target_id):
            bot.send_message(message.chat.id, "⚠️ Пользователь не найден или ещё не запускал бота.")
            return

        user_state[message.from_user.id] = {"mode": "send", "target_id": target_id}
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel"))

        note = "\n<i>(Вы перешли по своей ссылке — можно отправить тестовое сообщение самому себе)</i>" if target_id == message.from_user.id else ""
        bot.send_message(
            message.chat.id,
            f"✍️ <b>Отправьте анонимное сообщение</b>\n\n"
            f"Можно прислать текст, фото, голосовое, кружочек или стикер.{note}",
            reply_markup=kb,
        )
        return

    user_state.pop(message.from_user.id, None)
    send_main_menu(message.chat.id, message.from_user.id)


@bot.message_handler(commands=["cancel"])
def cmd_cancel(message: types.Message):
    user_state.pop(message.from_user.id, None)
    bot.send_message(message.chat.id, "Действие отменено.")
    send_main_menu(message.chat.id, message.from_user.id)


@bot.message_handler(commands=["paysupport"])
def cmd_paysupport(message: types.Message):
    bot.send_message(
        message.chat.id,
        "🛠 <b>Поддержка по оплатам</b>\n\n"
        "Если звёзды списались, а подписка не активировалась — напишите администратору канала.",
    )


# ================= КНОПКИ И ОПЛАТА (59 STARS) =================
@bot.callback_query_handler(func=lambda call: True)
def handle_callbacks(call: types.CallbackQuery):
    uid = call.from_user.id
    save_user(call.from_user)

    if call.data == "cancel":
        user_state.pop(uid, None)
        bot.answer_callback_query(call.id, "Отменено")
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except Exception:
            pass
        send_main_menu(call.message.chat.id, uid)
        return

    if call.data == "profile":
        active, until_dt = get_sub_status(uid)
        if active:
            txt = f"⭐️ Подписка активна до {until_dt.strftime('%d.%m.%Y %H:%M')} UTC."
        else:
            txt = "Подписка не активна."
        bot.answer_callback_query(call.id, txt, show_alert=True)
        return

    if call.data == "buy_info":
        bot.answer_callback_query(call.id)
        kb = types.InlineKeyboardMarkup(row_width=1)
        kb.add(types.InlineKeyboardButton(f"⭐️ Оплатить {SUB_PRICE_STARS} ★", callback_data="send_invoice"))
        kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="cancel"))

        bot.send_message(
            call.message.chat.id,
            f"👁 <b>Подписка «Видеть отправителей» — {SUB_PRICE_STARS} ★</b>\n\n"
            f"• Срок действия: <b>{SUB_DAYS} дней</b>\n"
            "• Показывает имя, ссылку на профиль и @username каждого, кто вам пишет.\n\n"
            "⚠️ <b>Важно:</b> имена открываются <b>только для новых сообщений</b>, "
            "которые придут <b>после оплаты</b>. Прошлые сообщения остаются анонимными.",
            reply_markup=kb,
        )
        return

    if call.data == "send_invoice":
        bot.answer_callback_query(call.id)
        bot.send_invoice(
            chat_id=call.message.chat.id,
            title=f"Видеть отправителей ({SUB_DAYS} дн.)",
            description=(
                "Открывает имя и @username отправителей всех НОВЫХ анонимных сообщений "
                "после оплаты. Прошлые сообщения не раскрываются."
            ),
            invoice_payload=f"sub_reveal_{SUB_DAYS}d",
            provider_token="",  # Для Telegram Stars всегда пустая строка
            currency="XTR",
            prices=[types.LabeledPrice(label=f"Подписка на {SUB_DAYS} дней", amount=SUB_PRICE_STARS)],
        )
        return

    if call.data.startswith("reply:"):
        msg_db_id = int(call.data.split(":")[1])
        record = get_message_sender(msg_db_id)
        if not record:
            bot.answer_callback_query(call.id, "Сообщение устарело.", show_alert=True)
            return

        original_sender_id, _ = record
        user_state[uid] = {"mode": "reply", "target_id": original_sender_id}
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel"))
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "↩️ <b>Напишите анонимный ответ:</b>", reply_markup=kb)
        return

    if call.data.startswith("again:"):
        target_id = int(call.data.split(":")[1])
        user_state[uid] = {"mode": "send", "target_id": target_id}
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel"))
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "✍️ <b>Напишите ещё одно анонимное сообщение:</b>", reply_markup=kb)
        return


@bot.pre_checkout_query_handler(func=lambda query: True)
def handle_pre_checkout(pre_checkout_query: types.PreCheckoutQuery):
    # Telegram requires an answer within 10 seconds.
    valid = (
        pre_checkout_query.currency == "XTR"
        and pre_checkout_query.total_amount == SUB_PRICE_STARS
        and pre_checkout_query.invoice_payload == f"sub_reveal_{SUB_DAYS}d"
    )
    bot.answer_pre_checkout_query(
        pre_checkout_query.id,
        ok=valid,
        error_message=None if valid else "Параметры оплаты не совпадают.",
    )


@bot.message_handler(content_types=["successful_payment"])
def handle_successful_payment(message: types.Message):
    sp = message.successful_payment
    save_user(message.from_user)
    if (
        sp.currency != "XTR"
        or sp.total_amount != SUB_PRICE_STARS
        or sp.invoice_payload != f"sub_reveal_{SUB_DAYS}d"
    ):
        logging.error("Rejected payment update with unexpected currency, amount, or payload")
        return
    new_until = activate_subscription(
        user_id=message.from_user.id,
        days=SUB_DAYS,
        amount=sp.total_amount,
        charge_id=sp.telegram_payment_charge_id,
    )
    bot.send_message(
        message.chat.id,
        "🎉 <b>Подписка активирована!</b>\n\n"
        f"Действует до: <b>{new_until.strftime('%d.%m.%Y %H:%M')} UTC</b>.\n"
        "Теперь во всех <b>новых</b> сообщениях, которые вам пришлют с этого момента, "
        "вы сразу увидите имя и @username отправителя.",
        reply_markup=main_menu_kb(message.from_user.id, True),
    )


# ================= ДОСТАВКА АНОНИМНЫХ СООБЩЕНИЙ =================
@bot.message_handler(
    content_types=["text", "photo", "video", "voice", "video_note", "sticker", "audio", "animation"]
)
def handle_anonymous_content(message: types.Message):
    uid = message.from_user.id
    save_user(message.from_user)

    if message.text and message.text.startswith("/"):
        return

    state = user_state.get(uid)
    if not state:
        send_main_menu(message.chat.id, uid)
        return

    target_id = state["target_id"]
    mode = state["mode"]

    # Ключевая проверка: подписка проверяется СТРОГО в момент прихода нового сообщения
    receiver_has_sub, _ = get_sub_status(target_id)
    msg_db_id = save_message_record(sender_id=uid, receiver_id=target_id)

    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(types.InlineKeyboardButton("↩️ Ответить анонимно", callback_data=f"reply:{msg_db_id}"))
    if not receiver_has_sub:
        kb.add(types.InlineKeyboardButton(f"👀 Кто написал? (новые за {SUB_PRICE_STARS} ★)", callback_data="buy_info"))

    header = "💬 <b>Пришёл анонимный ответ:</b>" if mode == "reply" else "📩 <b>Новое анонимное сообщение:</b>"
    sender_block = format_sender_block(message.from_user) if receiver_has_sub else ""

    try:
        if message.content_type == "text":
            safe_text = html.escape(message.text)
            bot.send_message(
                target_id,
                f"{header}\n\n{safe_text}{sender_block}",
                reply_markup=kb,
            )
        else:
            # copy_message скрывает автора медиафайла
            bot.copy_message(chat_id=target_id, from_chat_id=message.chat.id, message_id=message.message_id)
            bot.send_message(
                target_id,
                f"⬆️ {header}{sender_block}",
                reply_markup=kb,
            )

        user_state.pop(uid, None)
        after_kb = types.InlineKeyboardMarkup(row_width=1)
        after_kb.add(types.InlineKeyboardButton("✉️ Написать ещё", callback_data=f"again:{target_id}"))
        after_kb.add(types.InlineKeyboardButton("🔗 Получить свою ссылку", callback_data="cancel"))
        bot.send_message(message.chat.id, "✅ <b>Сообщение анонимно доставлено!</b>", reply_markup=after_kb)

    except Exception as exc:
        logging.warning("Message delivery failed (%s)", type(exc).__name__)
        user_state.pop(uid, None)
        bot.send_message(
            message.chat.id,
            "⚠️ Не удалось доставить сообщение (возможно, получатель остановил бота).",
        )


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.split("?", 1)[0] not in ("/api/healthz", "/healthz"):
            self.send_error(404)
            return
        payload = json.dumps({"status": "ok", "bot": BOT_USERNAME}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        return


def main():
    global BOT_USERNAME
    init_db()
    try:
        me = bot.get_me()
    except Exception as exc:
        logging.error("Could not connect to Telegram Bot API (%s); verify the new token and network.", type(exc).__name__)
        raise SystemExit(1) from None
    if not me.username:
        logging.error("Telegram returned a bot without a username.")
        raise SystemExit(1)

    BOT_USERNAME = me.username
    port = int(os.getenv("PORT", "8080"))
    health_server = ThreadingHTTPServer(("0.0.0.0", port), HealthHandler)
    Thread(target=health_server.serve_forever, daemon=True).start()
    logging.info("Bot @%s started; health endpoint is listening on port %s.", BOT_USERNAME, port)
    try:
        bot.infinity_polling(timeout=30, long_polling_timeout=25)
    finally:
        health_server.shutdown()
        health_server.server_close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("Bot stopped.")
    except SystemExit:
        raise
    except Exception as exc:
        logging.error("Bot stopped due to startup/runtime error (%s).", type(exc).__name__)
        raise SystemExit(1) from None
