# Запуск бота на Ubuntu 22.04

Бот использует Telegram long polling: домен и открытый входящий порт не нужны.
Нужны доступ по SSH, исходящее HTTPS-соединение, токен Telegram и PostgreSQL.
Порт PostgreSQL `5432` не открывайте в интернет.

## 1. Передать файлы на VPS

Скачайте из чата архив `telegram-anonymous-message-bot-vps.zip` и отдельный файл
`bot-data-migration.sql`. На своём компьютере откройте Terminal или PowerShell,
перейдите в папку загрузок и выполните команду, заменив `SSH_USER` и `VPS_IP`
значениями из панели вашего VPS:

```bash
scp telegram-anonymous-message-bot-vps.zip bot-data-migration.sql SSH_USER@VPS_IP:/tmp/
```

Пароль вводите только в терминале SSH, не отправляйте его в чат.

## 2. Установить системные пакеты и развернуть код

```bash
sudo apt update
sudo apt install -y ca-certificates curl unzip postgresql postgresql-contrib
```

Создать отдельного системного пользователя и каталог проекта:

```bash
sudo useradd --system --user-group --create-home --home-dir /var/lib/telegram_bot \
  --shell /usr/sbin/nologin telegram_bot
sudo install -d -o telegram_bot -g telegram_bot /opt/telegram-anonymous-message-bot
sudo unzip /tmp/telegram-anonymous-message-bot-vps.zip \
  -d /opt/telegram-anonymous-message-bot
sudo chown -R telegram_bot:telegram_bot /opt/telegram-anonymous-message-bot
sudo rm /tmp/telegram-anonymous-message-bot-vps.zip
```

## 3. Установить Python 3.13 и зависимости

```bash
sudo -u telegram_bot -H sh -c 'curl -LsSf https://astral.sh/uv/install.sh | sh'
sudo -u telegram_bot -H sh -c \
  'export PATH="$HOME/.local/bin:$PATH"; cd /opt/telegram-anonymous-message-bot; uv python install 3.13; uv sync --frozen'
```

## 4. Подготовить локальную PostgreSQL-базу

Задайте пароль для роли БД в приглашении `createuser`, придумайте новый пароль и
сохраните его только в защищённом файле на VPS:

```bash
sudo -u postgres createuser --pwprompt telegram_bot
sudo -u postgres createdb --owner=telegram_bot telegram_bot
sudo -u postgres psql -d telegram_bot -v ON_ERROR_STOP=1 \
  -f /opt/telegram-anonymous-message-bot/deploy/vps/schema.sql
```

## 5. Импортировать существующие данные

```bash
sudo -u postgres psql -d telegram_bot -v ON_ERROR_STOP=1 \
  -f /tmp/bot-data-migration.sql
sudo rm /tmp/bot-data-migration.sql
```

Файл содержит данные пользователей и служебные записи бота. Не загружайте его в
GitHub и удалите локальную копию после импорта.

## 6. Добавить секреты на VPS

```bash
sudo install -d -o root -g telegram_bot -m 750 /etc/telegram-anonymous-message-bot
sudo install -o root -g telegram_bot -m 640 /dev/null \
  /etc/telegram-anonymous-message-bot/bot.env
sudo nano /etc/telegram-anonymous-message-bot/bot.env
```

Заполните файл (подставьте свои значения):

```text
TELEGRAM_BOT_TOKEN=токен_бота
DATABASE_URL=postgresql://telegram_bot:пароль_базы@127.0.0.1:5432/telegram_bot
PORT=8080
```

Токен и пароль не отправляйте в чат и не добавляйте в GitHub. Если пароль базы
содержит специальные символы, используйте URL-кодирование или задайте пароль из
букв и цифр.

## 7. Установить и включить службу

```bash
sudo cp /opt/telegram-anonymous-message-bot/deploy/vps/telegram-anonymous-message-bot.service \
  /etc/systemd/system/telegram-anonymous-message-bot.service
sudo systemctl daemon-reload
sudo systemctl enable telegram-anonymous-message-bot
```

Перед запуском на VPS остановите прежний экземпляр в Replit: один токен Telegram
не должен одновременно использоваться двумя long-polling процессами. Затем:

```bash
sudo systemctl start telegram-anonymous-message-bot
sudo systemctl status --no-pager telegram-anonymous-message-bot
sudo journalctl -u telegram-anonymous-message-bot -n 100 --no-pager
curl -fsS http://127.0.0.1:8080/healthz
```

Ожидаемый ответ проверки: `{"status": "ok", "bot": "..."}`. Служба будет
автоматически стартовать после перезагрузки и перезапускаться после сбоя.

Если бот не запустился, сначала остановите его на VPS командой
`sudo systemctl stop telegram-anonymous-message-bot`, затем при необходимости
снова запустите workflow в Replit. Не оставляйте оба экземпляра работающими.
