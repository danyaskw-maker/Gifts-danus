CREATE TABLE IF NOT EXISTS telegram_bot_users (
    user_id BIGINT PRIMARY KEY,
    username TEXT,
    full_name TEXT NOT NULL,
    sub_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS telegram_bot_messages (
    id SERIAL PRIMARY KEY,
    sender_id BIGINT NOT NULL,
    receiver_id BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS telegram_bot_payments (
    id SERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    amount INTEGER NOT NULL,
    charge_id TEXT NOT NULL,
    paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT telegram_bot_payments_charge_id_unique UNIQUE (charge_id)
);
